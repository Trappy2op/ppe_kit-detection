# ppe detection > 2025-11-21 5:25pm
https://universe.roboflow.com/trappy2op/ppe-detection-pwcf9

Provided by a Roboflow user
License: CC BY 4.0

